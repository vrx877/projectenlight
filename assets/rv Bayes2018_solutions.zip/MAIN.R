################################################################################
#
#  Summer School 2018 - Take-Home Exam
#  Bayesian Econometrics
#
#  ---- Suggested solutions for the computer program ----
#
################################################################################

rm(list = ls())

library(mvtnorm)
library(coda)

source("mcmc_biprobit.R")

# ==============================================================================
# Part C: Simulation exercise

# ------------------------------------------------------------------------------
# generate data

set.seed(1234)

# model paremeters
nobs <- 1000
beta1 <- .8
beta2 <- -.4
delta <- .5
gamma <- .7
rho <- 0.5

# covariates
x <- rnorm(nobs)
z <- rnorm(nobs)

# error terms
sigma <- matrix(c(1, rho, rho, 1), 2, 2)
eps <- rmvnorm(nobs, mean = c(0, 0), sigma = sigma)

# latent utilities and observed variables
ystar2 <- x * beta2 + gamma * z + eps[, 2]
y2 <- rep(0, nobs)
y2[ystar2 > 0] <- 1

ystar1 <- x * beta1 + delta * y2 + eps[, 1]
y1 <- rep(0, nobs)
y1[ystar1 > 0] <- 1

# check means of binary variables
mean(y1)
mean(y2)

# ------------------------------------------------------------------------------
# run MCMC sampler

x1 <- cbind(x, y2)
x2 <- cbind(x, z)
colnames(x1) <- c("x", "y2")
colnames(x2) <- c("x", "z")

# ----- fixed zero correlation (rho = 0.0)

post1 <- mcmc_biprobit(y1, y2, x1, x2, sample_rho = FALSE, rho_start = 0)

mcmc1 <- as.mcmc(post1)
summary(mcmc1)
plot(mcmc1)

# ----- unknown correlation (rho is sampled)

post2 <- mcmc_biprobit(y1, y2, x1, x2, sample_rho = TRUE, rho_s2 = 3/nobs)

# compute M-H acceptance rate for rho
post2_MHacc <- mean(diff(post2$rho) != 0)
post2_MHacc

mcmc2 <- as.mcmc(post2)
summary(mcmc2)
plot(mcmc2)


# ==============================================================================
# Part C: Empirical application

source("mcmc_biprobit.R")

# ------------------------------------------------------------------------------
# data preparation

load("data/fertility.RData")

# names of covariates
xlab <- c("age", "agesq", "tv", "electric", "urban", "evermarr")

y1 <- dataset$kids     # exogenous variable
y2 <- dataset$educ     # endogenous variable
x  <- dataset[, xlab]  # covariates
z  <- dataset$fhalf    # instrument

# add vector of ones for intercept terms
x1 <- cbind("const" = 1, x, "educ" = y2)
x2 <- cbind("const" = 1, x, "fhalf" = z)

# number of observations in data set
nobs <- nrow(x1)

# ---- 'mean individual' used to compute marginal effect of education
#       on fertility
# which variables are binary?
is_binary <- function(x) { all(x %in% c(0, 1)) }
x1bin <- apply(x1, 2, is_binary)
# covariates for "mean individual"
x1mean <- colMeans(x1)
x1mean[x1bin] <- as.numeric(x1mean[x1bin] > 0.5)
# age and age squared (rescale appropriately)
x1mean["age"] <- mean(10 * dataset$age) / 10
x1mean["agesq"] <- mean(10 * dataset$age)^2 / 1000
# switch education variable
x1mean_educ1 <- x1mean_educ0 <- x1mean
x1mean_educ1["educ"] <- 1
x1mean_educ0["educ"] <- 0
# function for posterior distribution of marginal effect
post_margeff <- function(mcmc) {
  require(coda)
  beta1 <- mcmc[, grepl("beta1", colnames(mcmc))]
  beta1 <- as.matrix(beta1)
  margeff <- pnorm(beta1 %*% x1mean_educ1) - pnorm(beta1 %*% x1mean_educ0)
  cat("mean marginal effect =", mean(margeff), "\n")
  cat("HPD(95%) =", HPDinterval(as.mcmc(margeff), prob = 0.95), "\n")
  cat("Prob(margeff < 0 | data) =", mean(margeff < 0), "\n")
  return(margeff)
}

# ------------------------------------------------------------------------------
# MCMC sampling

iter <- 20000
burnin <- 1000

# ---- with fixed zero correlation
set.seed(1234)
fertil1_post <- mcmc_biprobit(y1, y2, x1, x2, iter, burnin, sample_rho = FALSE,
                              rho_start = 0)

fertil1_mcmc <- as.mcmc(fertil1_post)
plot(fertil1_mcmc)
summary(fertil1_mcmc)

fertil1_margeff <- post_margeff(fertil1_post)

# ---- with unrestricted correlation and non-informative prior on rho
set.seed(1234)
fertil2_post <- mcmc_biprobit(y1, y2, x1, x2, iter, burnin, sample_rho = TRUE,
                              rho_s2 = 3/nobs)
# M-H acceptance rate
fertil2_MHacc <- mean(diff(fertil2_post$rho) != 0)

fertil2_mcmc <- as.mcmc(fertil2_post)
plot(fertil2_mcmc)
summary(fertil2_mcmc)

fertil2_margeff <- post_margeff(fertil2_post)

# ---- with unrestricted correlation and informative prior on rho
set.seed(1234)
fertil3_post <- mcmc_biprobit(y1, y2, x1, x2, iter, burnin, sample_rho = TRUE,
                              rho_mean0 = 0.6, rho_var0 = 0.1^2,
                              rho_s2 = 2/nobs)
# M-H acceptance rate
fertil3_MHacc <- mean(diff(fertil3_post$rho) != 0)

fertil3_mcmc <- as.mcmc(fertil3_post)
plot(fertil3_mcmc)
summary(fertil3_mcmc)

fertil3_margeff <- post_margeff(fertil3_post)

# check effect of instrument
mean(fertil3_post$beta2.fhalf < 0)
