
mcmc_biprobit <- function(y1, y2, x1, x2, iter = 10000, burnin = 1000,
                          sample_rho = FALSE, B0 = 100, rho_mean0 = 0,
                          rho_var0 = 1, rho_s2 = 1/nobs, rho_start = 0,
                          beta1_start, beta2_start) {

  require(mvtnorm)    # for the multivariate normal distribution
  require(truncnorm)  # for the truncated normal distribution

  # convert x1 and x2 to numeric matrices
  x1 <- as.matrix(x1)
  x2 <- as.matrix(x2)

  # numbers of observations and of covariates
  nobs <- length(y1)
  k1 <- ncol(x1)
  k2 <- ncol(x2)

  # save cross-products to avoid recomputing at each MCMC interation
  x <- cbind(x1, x2)
  xx <- t(x) %*% x

  # generate useful ingredients for sampling of latent utilities
  # create vector of lower and upper bounds for latent utilities
  y1_upper <- rep(0, nobs)
  y1_lower <- rep(0, nobs)
  y2_upper <- rep(0, nobs)
  y2_lower <- rep(0, nobs)
  y1_upper[y1 == 1] <-  Inf
  y1_lower[y1 == 0] <- -Inf
  y2_upper[y2 == 1] <-  Inf
  y2_lower[y2 == 0] <- -Inf

  # containers for MCMC draws
  MCMC_beta1 <- matrix(NA, iter, k1)
  MCMC_beta2 <- matrix(NA, iter, k2)
  MCMC_rho <- rep(NA, iter)

  # starting values
  beta1 <- if (missing(beta1_start)) rep(0, k1) else beta1_start
  beta2 <- if (missing(beta2_start)) rep(0, k2) else beta2_start
  ystar1 <- abs(rnorm(nobs)) * sign(y1 - 0.5)
  ystar2 <- abs(rnorm(nobs)) * sign(y2 - 0.5)
  rho <- rho_start

  # ----- MCMC sampling
  for (rep in 1:(burnin + iter)) {

    if (rep %% 100 == 0) cat("rep =", rep, "\n")

    # ---- sample latent utilities
    y1_mean <- x1 %*% beta1
    y2_mean <- x2 %*% beta2
    ystar1 <- rtruncnorm(1, a = y1_lower,
                            b = y1_upper,
                            mean = y1_mean + rho * (ystar2 - y2_mean),
                            sd = sqrt(1 - rho^2))
    ystar2 <- rtruncnorm(1, a = y2_lower,
                            b = y2_upper,
                            mean = y2_mean + rho * (ystar1 - y1_mean),
                            sd = sqrt(1 - rho^2))

    # ---- sample regression coefficients
    post_var <- xx / (1 - rho^2)
    post_var[1:k1, k1 + 1:k2] <- -rho * post_var[1:k1, k1 + 1:k2]
    post_var[k1 + 1:k2, 1:k1] <- -rho * post_var[k1 + 1:k2, 1:k1]
    post_var <- post_var + diag(k1 + k2) / B0
    post_var <- solve(post_var)

    post_mean <- c(colSums((ystar1 - rho * ystar2) * x1),
                   colSums((ystar2 - rho * ystar1) * x2))
    post_mean <- post_var %*% post_mean / (1 - rho^2)

    beta <- rmvnorm(1, mean = post_mean, sigma = post_var)
    beta1 <- beta[1:k1]
    beta2 <- beta[k1 + 1:k2]

    # ---- sample correlation coefficient
    if (sample_rho) {
      # make proposal
      rho_old <- rho
      rho_new <- rho_old + rnorm(1, mean = 0, sd = sqrt(rho_s2))
      if (abs(rho_new) < 1) {
        # compute log of likelihoods ratio
        yd <- cbind(ystar1 - x1 %*% beta1,
                    ystar2 - x2 %*% beta2)
        sigma_old <- matrix(c(1, rho_old, rho_old, 1), 2, 2)
        sigma_new <- matrix(c(1, rho_new, rho_new, 1), 2, 2)
        ln_ratio_llik <-
          sum(dmvnorm(yd, sigma = sigma_new, log = TRUE)) -
          sum(dmvnorm(yd, sigma = sigma_old, log = TRUE))
        # compute log of prior densities ratio
        ln_ratio_prior <-
          dnorm(rho_new, mean = rho_mean0, sd = sqrt(rho_var0), log = TRUE) -
          dnorm(rho_old, mean = rho_mean0, sd = sqrt(rho_var0), log = TRUE)
        # compute acceptance ratio
        ln_R <- ln_ratio_llik + ln_ratio_prior
        alpha <- min(1, exp(ln_R))
        # accept or reject proposal
        u <- runif(1)
        if (u <= alpha) rho <- rho_new
      }
    }

    # ---- save draws after burnin
    if (rep > burnin) {
      j <- rep - burnin
      MCMC_beta1[j, ] <- beta1
      MCMC_beta2[j, ] <- beta2
      MCMC_rho[j] <- rho
    }

  } # end of MCMC loop

  # ---- label and return MCMC draws
  lab1 <- colnames(x1)
  lab2 <- colnames(x2)
  if (is.null(lab1)) lab1 <- 1:k1
  if (is.null(lab2)) lab2 <- 1:k2
  colnames(MCMC_beta1) <- paste("beta1", lab1, sep = ":")
  colnames(MCMC_beta2) <- paste("beta2", lab2, sep = ":")
  draws <- data.frame(MCMC_beta1, MCMC_beta2, "rho" = MCMC_rho)
  return(draws)

}
