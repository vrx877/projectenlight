# ---- gibbs_ordprobit
#
# Gibbs sampler for the ordered probit model with three choices
#
# MODEL:
#    Ystar = X * beta + e        e ~ N(0, 1)
#    Y = 1   if        Ystar <= 0
#    Y = 2   if    0 < Ystar <= tau
#    Y = 3   if  tau < Ystar
#
#  PARAMETERS:
#    beta          regression coefficients
#    tau           second cutpoint (first cutpoint set to 0 for identification)
#
# FLAT PRIOR:
#    p(beta, tau) proportional to 1, subject to the right ordering of the
#    cutpoints
#
# INPUT:
#    Y             dependent variable (integer vector with only 1, 2 or 3)
#    X             matrix of explanatory variables
#    burnin        burn-in period (number of iterations discarded at beginning)
#    iter          number of MCMC iterations saved (after burn-in)
#    beta.start    starting values for the regression coefficients
#    tau.start     starting value for the cutpoint
#
# OUTPUT:
#    data frame containing the MCMC draws of the regression coefficients
#    and of the cutpoint
#
# Notes: This code is not optimized for efficiency.
# No sanity checks performed on input arguments. Make sure they have the
# expected formats and dimensions.

gibbs_ordprobit <- function(Y, X, burnin = 1000, iter = 10000, beta.start,
                            tau.start) {

  require(mvtnorm)        # for the multivariate normal distribution
  require(truncnorm)      # for the truncated normal distribution

  # ---- model dimensions
  N <- length(Y)          # number of observations
  P <- ncol(X)            # number of explanatory variables

  # ---- containers for MCMC draws
  beta.mcmc <- matrix(NA, nrow = iter, ncol = P)
  tau.mcmc  <- rep(NA, iter)

  # ---- starting values
  beta.mcmc[1, ] <- beta <- beta.start
  tau.mcmc[1] <- tau <- tau.start

  # ---- ingredient fixed during sampling
  # inverse of cross-product of matrix of explanatory variables
  XXinv <- solve(t(X) %*% X)
  # cutpoints for the latent variable:
  #    if Y = 1  then  -Inf < Ystar <= 0
  #    if Y = 2  then     0 < Ystar <= tau
  #    if Y = 3  then   tau < Ystar < Inf
  # we create two vectors for the lower and upper cutpoints of the latent
  # variable, where only tau is left undefined (NA), as it will be updated
  # during MCMC sampling.
  # vector of lower cutpoints:
  Ylow <- rep(NA, N)
  Ylow[Y == 1] <- -Inf
  Ylow[Y == 2] <- 0
  # vector of upper cutpoints:
  Yupp <- rep(NA, N)
  Yupp[Y == 1] <- 0
  Yupp[Y == 3] <- Inf

  # ---- Gibbs sampling
  for (t in 2:(burnin + iter)) {

    if (t %% 1000 == 0) {
      cat(t, "iterations\n")
    }

    # sample ystar | beta, tau
    Ylow[Y == 3] <- tau
    Yupp[Y == 2] <- tau
    Ystar <- rtruncnorm(N, a = Ylow, b = Yupp, mean = X %*% beta, sd = 1)

    # sample tau | ystar
    tau <- runif(1, min = max(0, max(Ystar[Y == 2])),
                    max = min(Ystar[Y == 3]))

    # sample beta | ystar
    post.B <- XXinv
    post.b <- XXinv %*% t(X) %*% Ystar
    beta <- c(rmvnorm(1, mean = post.b, sigma = post.B))

    # save MCMC draws (after burn-in only)
    if (t > burnin) {
      beta.mcmc[t - burnin, ] <- beta
      tau.mcmc[t - burnin] <- tau
    }

  }

  # return MCMC draws
  mcmc <- data.frame(beta = beta.mcmc, tau = tau.mcmc)
  return(mcmc)

}
