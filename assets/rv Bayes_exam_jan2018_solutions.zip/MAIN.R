################################################################################
##  Summer School in Bayesian Econometrics
##  Take-Home Exam - January 8-15, 2018
##  Solution code (indicative only)
##  Note: This code is not optimized for efficiency
################################################################################

library(coda)                 # package used to summarize posterior distribution
library(MCMCpack)             # for Metropolis-Hastings algorithm
source("gibbs_ordprobit.R")   # function for Gibbs sampling of ordered probit

# ---- data generation

set.seed(12345)                    # set seed of random number generator
N    <- 500                        # number of observations
beta <- c(0.5, 0.3)                # regression coefficients
tau  <- 1                          # cutpoint
X    <- cbind(1, rnorm(N))         # explanatory variable (first column is
                                   #   a vector of 1s for intercept term)

Ystar <- X %*% beta + rnorm(N)                   # latent variable
Y <- cut(Ystar, breaks = c(-Inf, 0, tau, Inf))   # observed variable
Y <- as.integer(Y)

# # generate observed variable without the cut function:
# Y <- rep(NA, N)
# for (i in 1:N) {
#   if (Ystar[i] < 0) {
#     Y[i] <- 1
#   } else if (Ystar[i] < tau) {
#     Y[i] <- 2
#   } else {
#     Y[i] <- 3
#   }
# }

# ---- Gibbs sampling
beta.ols <- solve(t(X)%*%X)%*%t(X)%*%Y    # OLS as starting values for beta
post <- gibbs_ordprobit(Y, X, burnin = 1000, iter = 10000, beta.ols, tau)

# ---- summarize posterior
post <- as.mcmc(post)
plot(post)
summary(post)
acf(post[, "tau"], main = "Autocorrelogram of tau2")
